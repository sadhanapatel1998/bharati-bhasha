import { NextResponse } from 'next/server';
import { SESSION_COOKIE } from '@/server/lib/auth';

export const runtime = 'nodejs';

export async function POST() {
  const res = NextResponse.json({ success: true, message: 'Signed out' });
  res.cookies.set(SESSION_COOKIE, '', { path: '/', maxAge: 0 });
  return res;
}
